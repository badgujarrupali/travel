# database information
MysqlInfo={
'DBUsrName':'root',
'DBPasswd':'password',
'DBName'  :'soham_holidays',
'DBHost'  :'localhost'		
}
