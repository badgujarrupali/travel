from app import app
from flask import request, render_template
from app.controller import travel_controller


@app.route('/',methods=['GET','POST'])
def get_data():
    return render_template("admin.html")
    
@app.route('/enquiry', methods=['GET', 'POST'])
def enquiry():

    data = None
    if request.method == 'POST':
        data = travel_controller.enquiry_controller(request.json)

    return data
 
@app.route('/getEnquiryTypeList', methods=['GET', 'POST'])
def getEnquiryTypeList():
    data = None
    data = travel_controller.get_enquiry_type()
    return data

@app.route('/getAllEnquiry', methods=['GET', 'POST'])
def getAllEnquiry():
    data = None
    data = travel_controller.get_all_enquiry()
    return data

@app.route('/getSingleEnquiry', methods=['GET', 'POST'])
def getSingleEnquiry():
    data = None
    if request.method == 'POST':
       data = travel_controller.get_single_enquiry(request.json)
    return data 

@app.route('/storeEnquiryStatus', methods=['GET', 'POST'])
def storeEnquiryStatus():
    data = None
    if request.method == 'POST':
       data = travel_controller.storeEnquiryStatusData(request.json)
    return data
    
# @app.route('/genralEnquiry', methods=['GET', 'POST'])
# def genralEnquiry():
#     data = None
#     if request.method == 'POST':
#         # print request.json 
#         data = travel_controller.genral_enquiry(request.json)
#     return data

# @app.route('/rentCarEnquiry', methods=['GET', 'POST'])
# def rentCarEnquiry():
#     data = None
#     if request.method == 'POST':
#         print request.json 
#         data = travel_controller.rent_car_enquiry(request.json)
#     return data

# @app.route('/busOnHireEnquiry', methods=['GET', 'POST'])
# def busOnHireEnquiry():
#     data = None
#     if request.method == 'POST':
#         print request.json 
#         data = travel_controller.bus_on_hire_enquiry(request.json) 
#     return data
      
# @app.route('/airTicketEnquiry', methods=['GET', 'POST'])
# def airTicketEnquiry():
#     data = None
#     if request.method == 'POST':
#         print request.json 
#         data = travel_controller.air_ticket_enquiry(request.json) 
#     return data

# @app.route('/busTicketEnquiry', methods=['GET', 'POST'])
# def busTicketEnquiry():
#     data = None
#     if request.method == 'POST':
#         print request.json 
#         data = travel_controller.bus_ticket_enquiry(request.json) 
#     return data 

# @app.route('/trainTicketEnquiry', methods=['GET', 'POST'])
# def trainTicketEnquiry():
#     data = None
#     if request.method == 'POST':
#         print request.json 
#         data = travel_controller.train_ticket_enquiry(request.json) 
#     return data 

# @app.route('/hotelReservationEnquiry', methods=['GET', 'POST'])
# def hotelReservationEnquiry():
#     data = None
#     if request.method == 'POST':
#         print request.json 
#         data = travel_controller.hotel_reservation_enquiry(request.json) 
#     return data 
    
