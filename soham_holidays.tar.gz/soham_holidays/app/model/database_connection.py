import MySQLdb
from app.config import MysqlInfo
import mysql.connector.pooling


def EstablishDBConnecton():
    global pool_db
    try:
        print "Establishing connection"
        pool_db = mysql.connector.pooling.MySQLConnectionPool(pool_name="mypool",pool_size=15,host=MysqlInfo['DBHost'],user=MysqlInfo['DBUsrName'],password=MysqlInfo['DBPasswd'],database=MysqlInfo['DBName'],charset='utf8',use_unicode=True,raw=True)
    except Exception as e:
        print "Exception :"+str(e)
        pool_db = mysql.connector.pooling.MySQLConnectionPool(pool_name="mypool",pool_size=15,host=MysqlInfo['DBHost'],user=MysqlInfo['DBUsrName'],password=MysqlInfo['DBPasswd'],database=MysqlInfo['DBName'],charset='utf8',use_unicode=True,raw=True)


def conversion(data):
    print "conv data",data
    if type(data) is not list and type(data) is not tuple:
        print "converted direct data",str(data)
        return data
    ret=[]
    ret1=[]
    for row in data:
        #print(row)
        #print(type(row))
        if type(row) is list or type(row) is tuple:
            for each in row:
                ret.append(str(each.decode()))
            ret1.append(ret)
            ret=[]
        else:    
            if row is None:
                ret1.append(row)
            else:
                ret1.append(str(row.decode()))
    print "converted data",ret1
    return ret1
    
EstablishDBConnecton()