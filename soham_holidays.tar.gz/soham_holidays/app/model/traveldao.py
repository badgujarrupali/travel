from app.model import database_connection as database
from datetime import datetime
cursor = None

def opencursor1():           
    conn=database.pool_db.get_connection()
    cursor=conn.cursor(buffered=True)
    return conn,cursor
            
def closecursor(conn,cursor):
    cursor.close()
    conn.close()


def get_enquiry_type_list():
    data = None
    conn,cursor=opencursor1()
    sql="select name,label from enquiry_type"
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchall()
    except Exception as e:
        print(str(e))
        data = "DBError"
    closecursor(conn,cursor)
    return data

def get_all_enquiry():
    data = None
    conn,cursor=opencursor1()
    sql="select id, name, mobile, email,enquiry_name, enquiry_type,status,created_date from all_enquiry order by id desc"
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchall()
    except Exception as e:
        data = "DBError"
    # cursor.close()
    closecursor(conn,cursor)
    return data


def get_single_enquiry(report_id):
    data = None
    conn,cursor=opencursor1()
    sql="select enquiry_type from all_enquiry where id='"+str(report_id)+"'"
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchall()
    except Exception as e:
        data = "DBError"
    # cursor.close()
    closecursor(conn,cursor)
    return data

def get_train_bus_air_enquiry(report_id):
    data = None
    print(report_id)
    conn,cursor=opencursor1()
    sql="select a.id,a.name,a.mobile,a.email,a.enquiry_name,a.enquiry_type,a.created_date,a.status,s.num_of_adults,s.num_of_kids,\
    s.travel_from,s.travel_to,s.date_of_travel,s.return_status,s.return_date,s.comment_travel_ticket,\
    s.drop_to_source,s.pickup_from_destination,s.comment_travel_drop,s.hotel_booking,s.car_booking,\
    s.comment_booking from all_enquiry a inner join train_bus_air_ticket_enq s \
    on a.id=s.all_enquiry_id where a.id='"+str(report_id)+"'"
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchall()
    except Exception as e:
        data = "DBError"
    # cursor.close()
    closecursor(conn,cursor)

    return data

def get_bus_car_enquiry(report_id):
    data = None
    print(report_id)
    conn,cursor=opencursor1()
    sql="select a.id,a.name,a.mobile,a.email,a.enquiry_name,a.enquiry_type,a.created_date,s.num_of_ppl,\
        s.travel_from,s.travel_to,s.date_of_travel,s.return_status,s.return_date,s.travel_type,s.hotel_booking,comment,a.status \
        from all_enquiry a inner join bus_car_enq s \
    on a.id=s.all_enquiry_id where a.id='"+str(report_id)+"'"
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchall()
    except Exception as e:
        data = "DBError"
    # cursor.close()
    closecursor(conn,cursor)
    return data

def get_hotel_reservation_enquiry(report_id):
    data = None
    print(report_id)
    conn,cursor=opencursor1()
    sql="select a.id,a.name,a.mobile,a.email,a.enquiry_name,a.enquiry_type,a.created_date,a.status,\
    s.num_of_adults,s.num_of_kids,s.checkin_date,s.checkout_date,s.destination,s.car_booking,\
    s.air_ticket,s.bus_ticket,s.train_ticket,comment from all_enquiry a inner join hotel_reservation_enq s\
    on a.id=s.all_enquiry_id where a.id='"+str(report_id)+"'"
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchall()
    except Exception as e:
        data = "DBError"
    # cursor.close()
    closecursor(conn,cursor)
    return data


def get_general_enquiry(report_id):
    data = None
    print(report_id)
    conn,cursor=opencursor1()
    sql="select a.id,a.name,a.mobile,a.email,a.enquiry_name,a.enquiry_type,a.created_date,comment,a.status \
        from all_enquiry a inner join general_enq s \
    on a.id=s.all_enquiry_id where a.id='"+str(report_id)+"'"
    print sql
    try:
        cursor.execute(sql)
        data = cursor.fetchall()
        print data
    except Exception as e:
        data = "DBError"
    # cursor.close()
    closecursor(conn,cursor)
    return data


def save_train_bus_air_ticket_enquiry(jsondata):
    conn,cursor=opencursor1()   
    data=None
    rowid=None
    sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,status,created_date)\
     values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"','"+str(jsondata['email_id'])+"',\
     '"+str(jsondata['enquiry_name'])+"','"+str(jsondata['enquiry_type'])+"','Created',now())"
    print sql
  
    try:
        cursor.execute(sql)
        rowid=cursor.lastrowid
        print rowid

        field_details=jsondata['field_details']
        for i in range(len(field_details)):
            sql="INSERT INTO train_bus_air_ticket_enq(num_of_adults,num_of_kids,travel_from,travel_to,\
            date_of_travel,return_status,return_date,comment_travel_ticket,drop_to_source,\
            pickup_from_destination,comment_travel_drop,hotel_booking,car_booking,comment_booking,\
            created_date,all_enquiry_id) values('"+str(field_details[i]['num_of_adults'])+"',\
            '"+str(field_details[i]['num_of_kids'])+"','"+str(field_details[i]['travel_from'])+"',\
            '"+str(field_details[i]['travel_to'])+"','"+str(field_details[i]['date_of_travel'])+"',\
            "+(str(field_details[i]['return_status']))+",'"+str(field_details[i]['return_date'])+"',\
            '"+str(field_details[i]['comment_travel_ticket'])+"',"+str(field_details[i]['drop_to_source'])+",\
            "+str(field_details[i]['pickup_from_destination'])+",'"+str(field_details[i]['comment_travel_drop'])+"',\
            "+str(field_details[i]['hotel_booking'])+","+str(field_details[i]['car_booking'])+",\
            '"+str(field_details[i]['comment_booking'])+"',now(),'"+str(rowid)+"')"
            print sql

            cursor.execute(sql)
        conn.commit()
        data="success"

        # storeMysqlData(self.sql)
    except Exception as e:
        data = "DBError"
        conn.rollback()
    
    closecursor(conn,cursor) 
    return data

def save_bus_car_enquiry(jsondata):
    conn,cursor=opencursor1()   
    data=None
    rowid=None
    sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,status,created_date)\
    values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"',\
    '"+str(jsondata['email_id'])+"','"+str(jsondata['enquiry_name'])+"',\
    '"+str(jsondata['enquiry_type'])+"','Created',now())"
    print sql
  
    try:
        cursor.execute(sql)
        rowid=cursor.lastrowid
        print rowid

        sql="INSERT INTO bus_car_enq(num_of_ppl,travel_from,travel_to,date_of_travel,return_status,\
        return_date,travel_type,hotel_booking,comment,created_date,all_enquiry_id)\
        values('"+str(jsondata['num_of_ppl'])+"','"+str(jsondata['travel_from'])+"',\
        '"+str(jsondata['travel_to'])+"','"+str(jsondata['date_of_travel'])+"',\
        "+str(jsondata['return_status'])+",'"+str(jsondata['return_date'])+"',\
        '"+str(jsondata['travel_type'])+"',"+str(jsondata['hotel_booking'])+",\
        '"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"
        print sql

        cursor.execute(sql)
        conn.commit()
        data="success"

        # storeMysqlData(self.sql)
    except Exception as e:
        data = "DBError"
        conn.rollback()
    
    closecursor(conn,cursor) 
    return data     

def save_hotelreservation_enquiry(jsondata):
    conn,cursor=opencursor1()   
    data=None
    rowid=None
    sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,status,created_date) \
    values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"','"+str(jsondata['email_id'])+"',\
    '"+str(jsondata['enquiry_name'])+"','"+str(jsondata['enquiry_type'])+"','Created',now())"
    print sql
   
    try:
        cursor.execute(sql)
        rowid=cursor.lastrowid
        print rowid

        field_details=jsondata['field_details']
        for i in range(len(field_details)):

            sql="INSERT INTO hotel_reservation_enq(num_of_adults,num_of_kids,checkin_date,checkout_date,\
            destination,car_booking,air_ticket,bus_ticket,train_ticket,comment,created_date,all_enquiry_id) \
            values('"+str(field_details[i]['num_of_adults'])+"','"+str(field_details[i]['num_of_kids'])+"',\
            '"+str(field_details[i]['checkin_date'])+"','"+str(field_details[i]['checkout_date'])+"',\
            '"+str(field_details[i]['destination'])+"',"+str(field_details[i]['car_booking'])+",\
            "+str(field_details[i]['air_ticket'])+","+str(field_details[i]['bus_ticket'])+",\
            "+str(field_details[i]['train_ticket'])+",'"+str(field_details[i]['comment'])+"',now(),\
            '"+str(rowid)+"')"
            print sql

            cursor.execute(sql)
        
        conn.commit()
        data="success"
    except Exception as e:
        data = "DBError"
        print(str(e))
        conn.rollback()
    
    closecursor(conn,cursor) 
    return data

def save_general_enquiry(jsondata):
    conn,cursor=opencursor1()   
    data=None
    rowid=None
    sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,status,created_date)\
    values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"',\
    '"+str(jsondata['email_id'])+"','"+str(jsondata['enquiry_name'])+"',\
    '"+str(jsondata['enquiry_type'])+"','Created',now())"
    print sql
  
    try:
        cursor.execute(sql)
        rowid=cursor.lastrowid
        print rowid

        # sql="INSERT INTO general_enq(comment,created_date,all_enquiry_id)\
        # values('"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"

        # sql="INSERT INTO general_enq(comment,created_date,all_enquiry_id)\
        # values(?, now(),?)('"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"
        # print sql

        cursor.execute("INSERT INTO general_enq(comment,created_date,all_enquiry_id)\
        values(%s,now(),%s)",(jsondata['comment'],rowid,))
        conn.commit()
        data="success"

        # storeMysqlData(self.sql)
    except Exception as e:
        print(str(e))
        data = "DBError"
        conn.rollback()
    
    closecursor(conn,cursor) 
    return data     

def storeEnquiryStatus(report_id,value):
    conn,cursor=opencursor1()   
    data=None
    sql="update all_enquiry set status='"+str(value)+"',updated_date=now() where id="+str(report_id)
    print sql
    try:
        cursor.execute(sql)
        conn.commit()
        data = "Success"
    except Exception as e:
        print(str(e))
        data = "DBError"
        conn.rollback()
    
    closecursor(conn,cursor)
    return data





















# def save_genral_enquiry(jsondata):
#     conn,cursor=opencursor1()   
#     data=None
#     rowid=None
#     sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,created_date) values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"','"+str(jsondata['email_id'])+"','"+str(jsondata['enquiry_name'])+"','"+str(jsondata['enquiry_type'])+"',now())"
#     print sql
  
#     try:
#         cursor.execute(sql)
#         rowid=cursor.lastrowid
#         print rowid

#         sql="INSERT INTO general_enq(comment,created_date,all_enquiry_id) values('"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"
#         print sql

#         cursor.execute(sql)
#         data="success"
#         conn.commit()

#         # storeMysqlData(self.sql)
#     except:
#         data = "DBError"
#         conn.rollback()
    
#     closecursor(conn,cursor)
#     return data     

# def save_rent_car_enquiry(jsondata):
#     conn,cursor=opencursor1()   
#     data=None
#     rowid=None
#     sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,created_date) values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"','"+str(jsondata['email_id'])+"','"+str(jsondata['enquiry_name'])+"','"+str(jsondata['enquiry_type'])+"',now())"
#     print sql
  
#     try:
#         cursor.execute(sql)
#         rowid=cursor.lastrowid
#         print rowid

#         sql="INSERT INTO rent_car_enq(num_of_ppl,car_from,car_to,date_of_travel,return_status,return_date,car_type,hotel_booking,comment,created_date,all_enquiry_id) values('"+str(jsondata['num_of_ppl'])+"','"+str(jsondata['car_from'])+"','"+str(jsondata['car_to'])+"','"+str(jsondata['date_of_travel'])+"','"+str(jsondata['car_type'])+"','"+str(jsondata['return_status'])+"','"+str(jsondata['return_date'])+"','"+str(jsondata['hotel_booking'])+"','"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"
#         print sql

#         cursor.execute(sql)
#         data="success"
#         conn.commit()

#         # storeMysqlData(self.sql)
#     except:
#         data = "DBError"
#         conn.rollback()
    
#     closecursor(conn,cursor) 
#     return data     
 
# def save_busonhire_enquiry(jsondata):
#     conn,cursor=opencursor1()   
#     data=None
#     rowid=None
#     sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,created_date) values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"','"+str(jsondata['email_id'])+"','"+str(jsondata['enquiry_name'])+"','"+str(jsondata['enquiry_type'])+"',now())"
#     print sql
  
#     try:
#         cursor.execute(sql)
#         rowid=cursor.lastrowid
#         print rowid

#         sql="INSERT INTO bus_on_hire_enq(num_of_ppl,bus_from,bus_to,date_of_travel,bus_type,hotel_booking,comment,created_date,all_enquiry_id) values('"+str(jsondata['num_of_ppl'])+"','"+str(jsondata['bus_from'])+"','"+str(jsondata['bus_to'])+"','"+str(jsondata['date_of_travel'])+"','"+str(jsondata['bus_type'])+"','"+str(jsondata['hotel_booking'])+"','"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"
#         print sql

#         cursor.execute(sql)
#         data="success"
#         conn.commit()

#         # storeMysqlData(self.sql)
#     except:
#         data = "DBError"
#         conn.rollback()
    
#     closecursor(conn,cursor) 
#     return data     

# def save_air_ticket_enquiry(jsondata):
#     conn,cursor=opencursor1()   
#     data=None
#     rowid=None
#     sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,created_date) values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"','"+str(jsondata['email_id'])+"','"+str(jsondata['enquiry_name'])+"','"+str(jsondata['enquiry_type'])+"',now())"
#     print sql
  
#     try:
#         cursor.execute(sql)
#         rowid=cursor.lastrowid
#         print rowid

#         sql="INSERT INTO air_ticket_enq(num_of_ppl,air_from,air_to,date_of_travel,return_status,return_date,comment_air_ticket,drop_to_source,pickup_from_destination,comment_airport_drop,hotel_booking,car_booking,comment_booking,created_date,all_enquiry_id) values('"+str(jsondata['num_of_ppl'])+"','"+str(jsondata['air_from'])+"','"+str(jsondata['air_to'])+"','"+str(jsondata['date_of_travel'])+"','"+str(jsondata['return_status'])+"','"+str(jsondata['return_date'])+"','"+str(jsondata['comment_air_ticket'])+"','"+str(jsondata['drop_to_source'])+"','"+str(jsondata['pickup_from_destination'])+"','"+str(jsondata['comment_airport_drop'])+"','"+str(jsondata['hotel_booking'])+"','"+str(jsondata['car_booking'])+"','"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"
#         print sql

#         cursor.execute(sql)
#         data="success"
#         conn.commit()

#         # storeMysqlData(self.sql)
#     except:
#         data = "DBError"
#         conn.rollback()
    
#     closecursor(conn,cursor) 
#     return data     
 
# def save_bus_ticket_enquiry(jsondata):
#     conn,cursor=opencursor1()   
#     data=None
#     rowid=None
#     sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,created_date) values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"','"+str(jsondata['email_id'])+"','"+str(jsondata['enquiry_name'])+"','"+str(jsondata['enquiry_type'])+"',now())"
#     print sql
  
#     try:
#         cursor.execute(sql)
#         rowid=cursor.lastrowid
#         print rowid

#         sql="INSERT INTO bus_ticket_enq(num_of_adults,num_of_kids,bus_from,bus_to,date_of_travel,return_status,return_date,bus_type,comment_bus_ticket,drop_to_source,pickup_from_destination,comment_bus_drop,hotel_booking,car_booking,comment_booking,created_date,all_enquiry_id) values('"+str(jsondata['num_of_adults'])+"','"+str(jsondata['num_of_kids'])+"','"+str(jsondata['bus_from'])+"','"+str(jsondata['bus_to'])+"','"+str(jsondata['date_of_travel'])+"','"+str(jsondata['return_status'])+"','"+str(jsondata['return_date'])+"','"+str(jsondata['bus_type'])+"','"+str(jsondata['comment_bus_ticket'])+"','"+str(jsondata['drop_to_source'])+"','"+str(jsondata['pickup_from_destination'])+"','"+str(jsondata['comment_bus_drop'])+"','"+str(jsondata['hotel_booking'])+"','"+str(jsondata['car_booking'])+"','"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"
#         print sql

#         cursor.execute(sql)
#         data="success"
#         conn.commit()

#         # storeMysqlData(self.sql)
#     except:
#         print Exception
#         data = "DBError"
#         conn.rollback()
    
#     closecursor(conn,cursor) 
#     return data     
 
# def save_train_ticket_enquiry(jsondata):
#     conn,cursor=opencursor1()   
#     data=None
#     rowid=None
#     sql="INSERT INTO all_enquiry(name,mobile,email,enquiry_name,enquiry_type,created_date) values('"+str(jsondata['name'])+"','"+str(jsondata['mobile_no'])+"','"+str(jsondata['email_id'])+"','"+str(jsondata['enquiry_name'])+"','"+str(jsondata['enquiry_type'])+"',now())"
#     print sql
  
#     try:
#         cursor.execute(sql)
#         rowid=cursor.lastrowid
#         print rowid

#         sql="INSERT INTO train_ticket_enq(num_of_adults,num_of_kids,train_from,train_to,date_of_travel,return_status,return_date,comment_train_ticket,drop_to_source,pickup_from_destination,comment_train_drop,hotel_booking,car_booking,comment_booking,created_date,all_enquiry_id) values('"+str(jsondata['num_of_adults'])+"','"+str(jsondata['num_of_kids'])+"','"+str(jsondata['train_from'])+"','"+str(jsondata['train_to'])+"','"+str(jsondata['date_of_travel'])+"','"+str(jsondata['return_status'])+"','"+str(jsondata['return_date'])+"','"+str(jsondata['comment_train_ticket'])+"','"+str(jsondata['drop_to_source'])+"','"+str(jsondata['pickup_from_destination'])+"','"+str(jsondata['comment_train_drop'])+"','"+str(jsondata['hotel_booking'])+"','"+str(jsondata['car_booking'])+"','"+str(jsondata['comment'])+"',now(),'"+str(rowid)+"')"
#         print sql

#         cursor.execute(sql)
#         data="success"
#         conn.commit()

#         # storeMysqlData(self.sql)
#     except:
#         data = "DBError"
#         conn.rollback()
    
#     closecursor(conn,cursor) 
#     return data



