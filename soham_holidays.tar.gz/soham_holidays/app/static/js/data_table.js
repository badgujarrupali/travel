function fun2() {
  $.ajax({
    url: "/getAllEnquiry",
    dataType: "json",
    type: "GET",
    success: function(jsondata) {
      content = "";
      // var content="<table id='example' class='table table-striped table-bordered' style=width:'100%'>";
      // content+="<tbody>";
      for (i = 0; i < jsondata.length; i++) {
        content += "<tr>";

        content +=
          '<td data-target="#myModal" data-toggle="modal" onClick="sendDetails(\'' +
          jsondata[i].id +
          "','" +
          jsondata[i].enquiry_type +
          "')\">" +
          (i + 1) +
          "</td>";
        content +=
          '<td data-target="#myModal" data-toggle="modal" onClick="sendDetails(\'' +
          jsondata[i].id +
          "','" +
          jsondata[i].enquiry_type +
          "')\">" +
          jsondata[i].name +
          "</td>";
        content +=
          '<td data-target="#myModal" data-toggle="modal" onClick="sendDetails(\'' +
          jsondata[i].id +
          "','" +
          jsondata[i].enquiry_type +
          "')\">" +
          jsondata[i].mobile_no +
          "</td>";
        content +=
          '<td data-target="#myModal" data-toggle="modal" onClick="sendDetails(\'' +
          jsondata[i].id +
          "','" +
          jsondata[i].enquiry_type +
          "')\">" +
          jsondata[i].email_id +
          "</td>";
        content +=
          '<td data-target="#myModal" data-toggle="modal" onClick="sendDetails(\'' +
          jsondata[i].id +
          "','" +
          jsondata[i].enquiry_type +
          "')\">" +
          jsondata[i].enquiry_name +
          "</td>";
        // content += '<td onClick="sendDetails(\''+jsondata[i].id+'\',\''+jsondata[i].enquiry_type+'\')">view details</td>'
        content +=
          '<td data-target="#myModal" data-toggle="modal" onClick="sendDetails(\'' +
          jsondata[i].id +
          "','" +
          jsondata[i].enquiry_type +
          "')\">" +
          jsondata[i].created_date +
          "</td>";
        content +=
          '<td data-target="#myModal" id="status' +
          jsondata[i].id +
          '" data-toggle="modal" onClick="sendDetails(\'' +
          jsondata[i].id +
          "','" +
          jsondata[i].enquiry_type +
          "')\">" +
          jsondata[i].status +
          "</td>";

        console.log(jsondata.id);
        content += "</tr>";
      }
      // content+=  "</tbody>"
      //    content+= "</table>"
      $("#dataTableBody").html(content);
      $("#dataTableMain").DataTable();
    }
  });
}

$(document).ready(function() {
  // $('#example').DataTable();
  fun2();
});
function checkFunction(lengthOfList, id) {
  for (i = 1; i < lengthOfList + 1; i++) {
    $("#collapse2" + i).hide();
  }
  $("#collapse2" + id).show();
}

function sendDetails(id, type) {
  setTimeout(function() {
    // $(".travel-hide").hide();
  }, 200);

  // $(".collapse2'+(j+1)+'").click(function)
  // window.location.href="trainbusair.html"
  var content = {
    report_id: id,
    reportType: type
  };
  $.ajax({
    url: "/getSingleEnquiry",
    method: "POST",
    data: JSON.stringify(content),
    contentType: "application/json; charset=utf-8",
    dataType: "JSON",
    async: false,
    success: function(jsondata) {
      header = "";
      if (jsondata.enquiry_type == "train_ticket") {
        header +=
          '<div class="text-center modal_head">Train Travel Enquiry</div>';
      } else if (jsondata.enquiry_type == "bus_ticket") {
        header +=
          '<div class="text-center modal_head">Bus Travel Enquiry</div>';
      } else if (jsondata.enquiry_type == "air_ticket") {
        header +=
          '<div class="text-center modal_head">Air Travel Enquiry</div>';
      } else if (jsondata.enquiry_type == "rent_car") {
        header +=
          '<div class="text-center modal_head">Rent a Car Enquiry</div>';
      } else if (jsondata.enquiry_type == "bus_on_hire") {
        header +=
          '<div class="text-center modal_head">Bus on Hire Enquiry</div>';
      } else if (jsondata.enquiry_type == "hotel_reservation") {
        header +=
          '<div class="text-center modal_head">Hotel Reservation Enquiry</div>';
      } else if (jsondata.enquiry_type == "general_enquiry") {
        header +=
          '<div class="text-center modal_head">Other General Enquiry</div>';
      }
      $(".modal_header").html(header);

      userinfo = "";
      if (
        jsondata.enquiry_type == "train_ticket" ||
        jsondata.enquiry_type == "bus_ticket" ||
        jsondata.enquiry_type == "air_ticket"
      ) {
        userinfo +=
          '<div class="text-center head-line">Persnol Information</div>';
        userinfo +=
          '<div class="row div-space"><div class="col-xs-4">Name </div><div class="col-xs-8">:<span class="space">' +
          jsondata.name +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Mobile No </div><div class="col-xs-8">:<span class="space">' +
          jsondata.mobile_no +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Email ID </div><div class="col-xs-8">:<span class="space">' +
          jsondata.email_id +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Enquiry Type </div><div class="col-xs-8">:<span class="space">' +
          jsondata.enquiry_name +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Date and Time </div><div class="col-xs-8">:<span class="space">' +
          jsondata.created_date +
          "</span></div></div>";
        // userinfo+='<div class="col-xs-4">Details :</div><div class="col-xs-8"></div></div>';
        for (var j = 0; j < jsondata.field_details.length; j++) {
          // userinfo+='<div class="row panel-group" id="accordion">'
          userinfo +=
            '<div class="text-center travel" onclick="checkFunction(\'' +
            jsondata.field_details.length +
            "','" +
            (j + 1) +
            "')\">Travel " +
            (j + 1) +
            "</div></div>";
          if (jsondata.enquiry_type == "air_ticket") {
            userinfo +=
              '<div class="travel-hide" id="collapse2' +
              (j + 1) +
              '"><div class="text-center travel1">Air Ticket Enquiry</div>';
          } else if (jsondata.enquiry_type == "bus_ticket") {
            userinfo +=
              '<div class="travel-hide" id="collapse2' +
              (j + 1) +
              '"><div class="text-center travel1">Bus Ticket Enquiry</div>';
          } else if (jsondata.enquiry_type == "train_ticket") {
            userinfo +=
              '<div class="travel-hide" id="collapse2' +
              (j + 1) +
              '" class=""><div class="text-center travel1">Train Ticket Enquiry</div>';
          }
          if (jsondata.enquiry_type == "air_ticket") {
            userinfo +=
              '<div class="row div-space"><div class="col-xs-4">No of People </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].num_of_adults +
              "</span></div>";
            // userinfo+='<div class="col-xs-4">No of Kids </div><div class="col-xs-8">:<span class="space">'+jsondata.field_details[j].num_of_kids+'</span></div>';
            userinfo +=
              '<div class="col-xs-4">Travel From </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].travel_from +
              "</span></div>";
            userinfo +=
              '<div class="col-xs-4">Travel To </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].travel_to +
              "</span></div>";
            userinfo +=
              '<div class="col-xs-4">Date of Travel </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].date_of_travel +
              "</span></div>";
          } else {
            userinfo +=
              '<div class="row div-space"><div class="col-xs-4">No of Adults </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].num_of_adults +
              "</span></div>";
            userinfo +=
              '<div class="col-xs-4">No of Kids </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].num_of_kids +
              "</span></div>";
            userinfo +=
              '<div class="col-xs-4">Travel From </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].travel_from +
              "</span></div>";
            userinfo +=
              '<div class="col-xs-4">Travel To </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].travel_to +
              "</span></div>";
            userinfo +=
              '<div class="col-xs-4">Date of Travel </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].date_of_travel +
              "</span></div>";
          }
          if (jsondata.field_details[j].return_status == "Return") {
            // userinfo+='<div class="col-xs-4">Return Status </div><div class="col-xs-8">:<span class="space">'+jsondata.field_details[j].return_status+'</span></div>';
            userinfo +=
              '<div class="col-xs-4">Return Date </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].return_date +
              "</span></div>";
          } else {
            userinfo +=
              '<div class="col-xs-4">Return Status </div><div class="col-xs-8">:<span class="space">' +
              jsondata.field_details[j].return_status +
              "</span></div>";
          }
          userinfo +=
            '<div class="col-xs-4">Comment </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].comment_travel_ticket +
            "</span></div></div>";
          if (jsondata.enquiry_type == "air_ticket") {
            userinfo +=
              '<div class="text-center travel1">Airport Transfer Enquiry</div>';
          } else if (jsondata.enquiry_type == "bus_ticket") {
            userinfo +=
              '<div class="text-center travel1">Bus Stop Transfer Enquiry</div>';
          } else if (jsondata.enquiry_type == "train_ticket") {
            userinfo +=
              '<div class="text-center travel1">Train Stop Transfer Enquiry</div>';
          }
          userinfo +=
            '<div class="row div-space"><div class="col-xs-4">Drop to Source </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].drop_to_source +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Pickup from Destination </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].pickup_from_destination +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Comment </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].comment_travel_drop +
            "</span></div></div>";

          userinfo +=
            '<div class="text-center travel1">Hotel/Car Enquiry</div>';

          userinfo +=
            '<div class="row div-space"><div class="col-xs-4">Hotel Booking </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].hotel_booking +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Car Booking </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].car_booking +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Comment </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].comment_booking +
            "</span></div></div></div>";
        }
      } else if (
        jsondata.enquiry_type == "rent_car" ||
        jsondata.enquiry_type == "bus_on_hire"
      ) {
        userinfo +=
          '<div class="text-center head-line">Personal Information</div>';
        userinfo +=
          '<div class="row div-space"><div class="col-xs-4">Name </div><div class="col-xs-8">:<span class="space">' +
          jsondata.name +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Mobile No </div><div class="col-xs-8">:<span class="space">' +
          jsondata.mobile_no +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Email ID </div><div class="col-xs-8">:<span class="space">' +
          jsondata.email_id +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Enquiry Type </div><div class="col-xs-8">:<span class="space">' +
          jsondata.enquiry_name +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Date and Time </div><div class="col-xs-8">:<span class="space">' +
          jsondata.created_date +
          "</span></div></div>";
        userinfo += '<div class="text-center  travel">Travel Details</div>';
        userinfo +=
          '<div class="row div-space"><div class="col-xs-4">No of People </div><div class="col-xs-8">:<span class="space">' +
          jsondata.num_of_ppl +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Travel From </div><div class="col-xs-8">:<span class="space">' +
          jsondata.travel_from +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4"> Travel To </div><div class="col-xs-8">:<span class="space">' +
          jsondata.travel_to +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Date of Travel </div><div class="col-xs-8">:<span class="space">' +
          jsondata.date_of_travel +
          "</span></div>";
        if (jsondata.return_status == "Return") {
          // userinfo+='<div class="col-xs-4">Return Status </div><div class="col-xs-8">:<span class="space">'+jsondata.return_status+'</span></div>';
          userinfo +=
            '<div class="col-xs-4">Return Date </div><div class="col-xs-8">:<span class="space">' +
            jsondata.return_date +
            "</span></div>";
        } else {
          userinfo +=
            '<div class="col-xs-4">Return Status </div><div class="col-xs-8">:<span class="space">' +
            jsondata.return_status +
            "</span></div>";
        }
        userinfo +=
          '<div class="col-xs-4">Type  </div><div class="col-xs-8">:<span class="space">' +
          jsondata.travel_type +
          "</span></div></div>";
        userinfo += '<div class="text-center travel1">Hotel Enquiry</div>';
        userinfo +=
          '<div class="row div-space"><div class="col-xs-4">Hotel Booking  </div><div class="col-xs-8">:<span class="space">' +
          jsondata.hotel_booking +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Comments </div><div class="col-xs-8">:<span class="space">' +
          jsondata.comment_booking +
          "</span></div></div>";
      } else if (jsondata.enquiry_type == "hotel_reservation") {
        userinfo +=
          '<div class="text-center head-line">Personal Information</div>';
        userinfo +=
          '<div class="row div-space"><div class="col-xs-4">Name </div><div class="col-xs-8">:<span class="space">' +
          jsondata.name +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Mobile No </div><div class="col-xs-8">:<span class="space">' +
          jsondata.mobile_no +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Email ID </div><div class="col-xs-8">:<span class="space">' +
          jsondata.email_id +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Enquiry Type </div><div class="col-xs-8">:<span class="space">' +
          jsondata.enquiry_name +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Date and Time </div><div class="col-xs-8">:<span class="space">' +
          jsondata.created_date +
          "</span></div></div>";
        // userinfo+='<div class="col-xs-4">Details :</div><div class="col-xs-8"></div></div>';
        for (var j = 0; j < jsondata.field_details.length; j++) {
          userinfo +=
            '<div class="row"><div class="text-center travel" onclick="checkFunction(\'' +
            jsondata.field_details.length +
            "','" +
            (j + 1) +
            "')\">Travel " +
            (j + 1) +
            "</div></div>";
          userinfo +=
            '<div class="row div-space" id="collapse2' +
            (j + 1) +
            '"><div class="col-xs-4">No of Adults </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].num_of_adults +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">No of Kids </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].num_of_kids +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Checkin Date </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].checkin_date +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Checkout Date </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].checkout_date +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Destination </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].destination +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Car Booking </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].car_booking +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Air Ticket </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].air_ticket +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Bus Ticket </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].bus_ticket +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Train Ticket </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].train_ticket +
            "</span></div>";
          userinfo +=
            '<div class="col-xs-4">Comment </div><div class="col-xs-8">:<span class="space">' +
            jsondata.field_details[j].comment +
            "</span></div></div>";
        }
      } else if (jsondata.enquiry_type == "general_enquiry") {
        userinfo +=
          '<div class="text-center head-line">Personal Information</div>';
        userinfo +=
          '<div class="row div-space"><div class="col-xs-4">Name </div><div class="col-xs-8">:<span class="space">' +
          jsondata.name +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Mobile No </div><div class="col-xs-8">:<span class="space">' +
          jsondata.mobile_no +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Email ID </div><div class="col-xs-8">:<span class="space">' +
          jsondata.email_id +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Enquiry Type </div><div class="col-xs-8">:<span class="space">' +
          jsondata.enquiry_name +
          "</span></div>";
        userinfo +=
          '<div class="col-xs-4">Date and Time </div><div class="col-xs-8">:<span class="space">' +
          jsondata.created_date +
          "</span></div></div>";
        userinfo += '<div class="text-center  travel">General Enquiry</div>';
        userinfo +=
          '<div class="row div-space"><div class="col-xs-4">Comments </div><div class="col-xs-8">:<span class="space">' +
          jsondata.comment +
          "</span></div></div></div>";
      }
      userinfo +=
        '<div class="row div-space"><div class="col-xs-4">Status </div><div class="col-xs-8"><span class="space">';
      userinfo +=
        '<div class="col-xs-5 status-margin"><select id="selectStatus" class="form-control">';
      if (jsondata.status == "Created") {
        userinfo += '<option value="Created" selected>Created</option>';
      } else {
        userinfo += '<option value="Created">Created</option>';
      }
      if (jsondata.status == "In Process") {
        userinfo += '<option value="In Process" selected>In Process</option>';
      } else {
        userinfo += '<option value="In Process">In Process</option>';
      }
      if (jsondata.status == "Completed") {
        userinfo += '<option value="Completed" selected>Completed</option>';
      } else {
        userinfo += '<option value="Completed">Completed</option>';
      }
      userinfo += "</select></div>";
      userinfo += "</div></div>";
      $(".modal-body").html(userinfo);

      footer =
        '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>';
      footer +=
        '<button type="button" class="btn btn-default" onclick="sendStatus(\'' +
        jsondata.id +
        '\')" data-dismiss="modal">Save</button>';
      $(".modal-footer").html(footer);

      if (
        jsondata.enquiry_type != "rent_car" &&
        jsondata.enquiry_type != "bus_on_hire"
      ) {
        for (i = 1; i < jsondata.field_details.length + 1; i++) {
          $("#collapse2" + i).hide();
        }

        $("#collapse21").show();
      }
    },
    error: function(error, xhr, status) {}
  });
}

function sendStatus(id) {
  value = $("#selectStatus").val();

  var content = {
    report_id: id,
    report_status: value
  };
  $.ajax({
    url: "/storeEnquiryStatus",
    method: "POST",
    data: JSON.stringify(content),
    contentType: "application/json; charset=utf-8",
    dataType: "html",
    async: false,
    success: function(jsondata) {
      if (jsondata == "Success") {
        $("#status" + id).html(value);
      }
    },
    error: function(error, xhr, status) {}
  });
}
