from app.model import traveldao
from app.controller import validation_control
import json 
from datetime import datetime, date
from cerberus import Validator
import time
import re

def enquiry_controller(jsondata):
    ret=None
    if jsondata['enquiry_type']=="air_ticket" or jsondata['enquiry_type']=="train_ticket"  or jsondata['enquiry_type']=="bus_ticket":
        ret=train_bus_air_ticket_enquiry(jsondata)
    elif jsondata['enquiry_type']=="rent_car" or jsondata['enquiry_type']=="bus_on_hire":
        ret=bus_car_enquiry(jsondata)
    elif jsondata['enquiry_type']=="hotel_reservation":
        ret=hotel_reservation_enquiry(jsondata)
    elif jsondata['enquiry_type']=="general_enquiry":
        ret=general_enquiry(jsondata)
    else:
        # ret=json.dumps({"status":"Enquiry type is not correct"})
        ret="Enquiry type is not correct"
    return ret

def storeEnquiryStatusData(jsondata):
    ret=None
    report_id=jsondata['report_id']
    value=jsondata['report_status']
    ret=traveldao.storeEnquiryStatus(report_id,value)
 
    return ret

#Date validation 
def date_validation(second_date,first_date=None,enquiry_type=None):
    # now2=time.strftime('%Y-%m-%d', time.localtime(time.time()))
    print (second_date)
    temp=first_date
    if first_date == None:
        first_date=time.strftime('%Y-%m-%d', time.localtime(time.time()))
        first_date=int(time.mktime(datetime.strptime(str(first_date), "%Y-%m-%d").timetuple()))

        # first_date=int(time.time())
    else:
        first_date=int(time.mktime(datetime.strptime(str(first_date), "%Y-%m-%d").timetuple()))

    second_date=int(time.mktime(datetime.strptime(str(second_date), "%Y-%m-%d").timetuple()))
    print(first_date)
    print (second_date)
    error=""
    if first_date>second_date:
        print ("please enter valid date")
        if temp==None:
            if(enquiry_type==None):
                field = "date_of_travel"
                error= "travel date must be greater than or equal to current date" 
            else:
                error= "checkin date must be greater than or equal to current date" 
                field = "date_of_travel"
        else:
            if(enquiry_type==None):
                field = "return_date"
                error= "return date must be greater than travel date" 
            else:
                field = "return_date"
                error= "checkout date must be greater than or equal to checkin date" 
    if error=="":
        return "success"
    else:
        temp={}
        temp["field"]=field
        temp["error"]=error
        return temp
 
def get_all_enquiry():
    ret=None
    ret=traveldao.get_all_enquiry() 
    print (ret)
    temp={}
    temp_list=[]
    for row in ret:
        temp['id']=row[0]
        temp['name']=row[1]
        temp['mobile_no']=row[2]
        temp['email_id']=row[3]
        temp['enquiry_name']=row[4]
        temp['enquiry_type']=row[5]
        temp['status']=row[6]
        old=datetime.strptime(row[7], "%Y-%m-%d %H:%M:%S")
        new=old.strftime(' %d %b %Y    %I:%M%p')
        temp['created_date']=new
        temp_list.append(temp)
        temp={}
    print (temp_list)
    return json.dumps(temp_list)

# get single enquiry report 

def get_single_enquiry(jsondata):
    ret=None

    print(jsondata)
    ret=traveldao.get_single_enquiry(jsondata['report_id'])
    if ret[0][0] =="air_ticket" or ret[0][0] =="train_ticket" or ret[0][0] =="bus_ticket":
        ret=get_train_bus_air_enquiry(jsondata)  
    elif ret[0][0] =="bus_on_hire" or ret[0][0] =="rent_car":
        ret=get_bus_car_enquiry(jsondata)    
    elif ret[0][0] =="hotel_reservation":
        ret=get_hotel_reservation_enquiry(jsondata)
    elif ret[0][0] =="general_enquiry":
        ret=get_general_enquiry(jsondata)    
    return ret

# get single report data for get_train_bus_car_enquiry

def get_train_bus_air_enquiry(jsondata):
    ret=None
    old=None
    new=None 
    ret=traveldao.get_train_bus_air_enquiry(jsondata['report_id']) 
    print (ret)
    temp={}
    temp_main={}
    temp_list=[]
    temp_main['id']=ret[0][0] 
    temp_main['name']=ret[0][1]
    temp_main['mobile_no']=ret[0][2]
    temp_main['email_id']=ret[0][3]
    temp_main['enquiry_name']=ret[0][4]
    temp_main['enquiry_type']=ret[0][5]
    old=datetime.strptime(ret[0][6], "%Y-%m-%d %H:%M:%S")
    new=old.strftime(' %d %b %Y %I:%M%p')
    temp_main['created_date']=new
    temp_main['status']=ret[0][7]

    for row in ret:
        temp['num_of_adults']=row[8]
        temp['num_of_kids']=row[9]
        temp['travel_from']=row[10]
        temp['travel_to']=row[11]
        old=datetime.strptime(row[12], "%Y-%m-%d %H:%M:%S")
        new=old.strftime('%d %b %Y')
        temp['date_of_travel']=new
        temp['return_status']="One way" if row[13]=='0' else "Return"
        if row[13]!='0':
            old=datetime.strptime(row[14], "%Y-%m-%d %H:%M:%S")
            new=old.strftime('%d %b %Y')
        else:
            new=""
        temp['return_date']=new
        temp['comment_travel_ticket']=row[15]
        temp['drop_to_source']="Not Required" if row[16]=='0' else "Required"
        temp['pickup_from_destination']="Not Required" if row[17]=='0' else "Required"
        temp['comment_travel_drop']=row[18]
        temp['hotel_booking']="Not Required" if row[19]=='0' else "Required"
        temp['car_booking']="Not Required" if row[20]=='0' else "Required"
        temp['comment_booking']=row[21]
        
        temp_list.append(temp.copy())
        temp={}
    temp_main['field_details']=temp_list
        # print (temp_list)
    return json.dumps(temp_main)
    # return "success"

# get single report data for bus_car_enquiry

def get_bus_car_enquiry(jsondata):
    ret=None
    old=None
    new=None
    ret=traveldao.get_bus_car_enquiry(jsondata['report_id']) 
    if ret==None:
        return "DBError"
    else:
        print (ret)
        temp={}
        # temp_list=[]
        # for row in ret:
        row=ret[0]
        temp['id']=row[0]
        temp['name']=row[1]
        temp['mobile_no']=row[2]
        temp['email_id']=row[3]
        temp['enquiry_type']=row[5]
        temp['enquiry_name']=row[4]
        old=datetime.strptime(row[6], "%Y-%m-%d %H:%M:%S")
        new=old.strftime(' %d %b %Y %I:%M%p')
        temp['created_date']=new
        temp['num_of_ppl']=row[7]
        temp['travel_from']=row[8]
        temp['travel_to']=row[9]
        old=datetime.strptime(row[10], "%Y-%m-%d %H:%M:%S")
        new=old.strftime('%d %b %Y')
        temp['date_of_travel']=new
        temp['return_status']="One Way" if row[11]=='0' else "Return"
        if row[11]!='0':
            old=datetime.strptime(row[12], "%Y-%m-%d %H:%M:%S")
            new=old.strftime('%d %b %Y')
        else:
            new=""

        temp['return_date']=new
        temp['travel_type']=row[13]
        temp['hotel_booking']="Not Required" if row[14]=='0' else "Required"
        temp['comment_booking']=row[15]
        temp['status']=row[16]
        return json.dumps(temp)
        # return "success"

# get single report data for hotel_reservation

def get_hotel_reservation_enquiry(jsondata):
    ret=None
    old=None
    new=None
    ret=traveldao.get_hotel_reservation_enquiry(jsondata['report_id'])
    if ret==None:
        return "DBError"
    else: 
        print (ret)
        temp={}
        temp_main={}
        temp_list=[]
        temp_main['id']=ret[0][0] 
        temp_main['name']=ret[0][1]
        temp_main['mobile_no']=ret[0][2]
        temp_main['email_id']=ret[0][3]
        temp_main['enquiry_type']=ret[0][5]
        temp_main['enquiry_name']=ret[0][4]
        old=datetime.strptime(ret[0][6], "%Y-%m-%d %H:%M:%S")
        new=old.strftime(' %d %b %Y %I:%M%p')
        temp_main['created_date']=new
        temp_main['status']=ret[0][7]
        for row in ret:
            temp['num_of_adults']=row[8]
            temp['num_of_kids']=row[9]
            old=datetime.strptime(row[10], "%Y-%m-%d %H:%M:%S")
            new=old.strftime('%d %b %Y')
            temp['checkin_date']=new
            old=datetime.strptime(row[11], "%Y-%m-%d %H:%M:%S")
            new=old.strftime('%d %b %Y')
            temp['checkout_date']=new
            temp['destination']=row[12]
            temp['car_booking']="Not Required" if row[13]=='0' else "Required"
            temp['air_ticket']="Not Required" if row[14]=='0' else "Required"
            temp['bus_ticket']="Not Required" if row[15]=='0' else "Required"
            temp['train_ticket']="Not Required" if row[16]=='0' else "Required" 
            temp['comment']=row[17]
            temp_list.append(temp.copy())
            temp={}
        temp_main['field_details']=temp_list
            # print temp_list
        return json.dumps(temp_main)
        # return "success"
def get_general_enquiry(jsondata):
    ret=None
    old=None
    new=None
    ret=traveldao.get_general_enquiry(jsondata['report_id']) 
    if ret==None:
        return "DBError"
    else:
        print (ret)
        temp={}
        row=ret[0]
        temp['id']=row[0]
        temp['name']=row[1]
        temp['mobile_no']=row[2]
        temp['email_id']=row[3]
        temp['enquiry_type']=row[5]
        temp['enquiry_name']=row[4]
        old=datetime.strptime(row[6], "%Y-%m-%d %H:%M:%S")
        new=old.strftime(' %d %b %Y %I:%M%p')
        temp['created_date']=new
        temp['comment']=row[7]
        temp['status']=row[8]

        return json.dumps(temp)
        # return "success"

def get_enquiry_type():
    ret=None
    ret=traveldao.get_enquiry_type_list()
    if ret==None:
        return "DBError"
    else:  
        print(ret)
        temp={}
        temp_list=[]
        for row in ret:
            temp['enquiry_type']=row[0]
            temp['enquiry_name']=row[1]
            temp_list.append(temp.copy())
            temp={}
        print (temp_list)
        return json.dumps(temp_list)
        # return "success"

def jsonResponse(ret):
    temp={"status":ret}
    return json.dumps(temp)

def train_bus_air_ticket_enquiry(jsondata):
    field_details=jsondata['field_details']
    ret=None
    errorlist=[]

    ret=validation_control.validation_all_field(jsondata)
    if ret != "success":
        errorlist+=ret
        
    for i in range(len(field_details)):
        print (len(field_details))
        ret=date_validation(field_details[i]['date_of_travel'])
        if ret != "success":
            errorlist.append(ret)
        if field_details[i]['return_status']==True:
            ret=date_validation(field_details[i]['return_date'],field_details[i]['date_of_travel'])
            if ret != "success":
                errorlist.append(ret)
                
    if errorlist==[]:
        ret=traveldao.save_train_bus_air_ticket_enquiry(jsondata) 
        return jsonResponse(ret)
    else:
        return json.dumps(errorlist)

def bus_car_enquiry(jsondata):
    print (jsondata)
    ret=None
    errorlist=[]

    ret=validation_control.validation_all_field(jsondata)
    if ret != "success":
        errorlist+=ret

    ret=date_validation(jsondata['date_of_travel'])
    if ret != "success":
        errorlist.append(ret)
    if jsondata['enquiry_type']=="rent_car":
        print jsondata['enquiry_type']
        if jsondata['return_status']==True:
            ret=date_validation(jsondata['return_date'],jsondata['date_of_travel'])
            if ret != "success":
                errorlist.append(ret)
    if errorlist==[]:
        ret=traveldao.save_bus_car_enquiry(jsondata) 
        return jsonResponse(ret)
    else:
        return json.dumps(errorlist)

def hotel_reservation_enquiry(jsondata):
    print jsondata
    field_details=jsondata['field_details']
    ret=None
    errorlist=[]

    ret=validation_control.validation_all_field(jsondata)
    if ret != "success":
        errorlist+=ret
    for i in range(len(field_details)):
        print len(field_details)
        ret=date_validation(field_details[i]['checkin_date'],enquiry_type=jsondata['enquiry_type'])
        if ret != "success":
            errorlist.append(ret)


        
        ret=date_validation(field_details[i]['checkout_date'],field_details[i]['checkin_date'],enquiry_type=jsondata['enquiry_type'])
        if ret != "success":
            errorlist.append(ret)

    if errorlist==[]:
        ret=traveldao.save_hotelreservation_enquiry(jsondata) 
        return jsonResponse(ret)
    else:
        return json.dumps(errorlist)
def general_enquiry(jsondata):
    print jsondata
    ret=None
    errorlist=[]

    ret=validation_control.validation_all_field(jsondata)
    if ret != "success":
        errorlist+=ret
    
    if errorlist==[]:
        ret=traveldao.save_general_enquiry(jsondata) 
        return jsonResponse(ret)
    else:
        return json.dumps(errorlist)



















# def air_ticket_enquiry(jsondata):
#     print jsondata
#     ret=None
#     args=['name','enquiry_type','enquiry_name','num_of_ppl','air_from','air_to','drop_to_source','pickup_from_destination','hotel_booking','car_booking']
#     print args
    
#     ret=enquiry_validation(jsondata)
#     if ret != "success":
#         return ret
    
#     ret=validation_all_field(args,jsondata)
#     if ret != "success":
#         return ret

#     date_of_travel=jsondata['date_of_travel']
#     if date_of_travel=="" or date_of_travel==None:
#         print "Please enter date of travel"
#         return "Please enter date of travel"
#     else:
#         print "date of travel is ok"
    
#     return_status=jsondata['return_status']
#     if return_status=="" or return_status==None:
#         print "Please select return status"
#         return "Please select return status"
#     else:
#         print "return status is ok"
    
#     if return_status==True:
#         return_date=jsondata['return_date']
#         if return_date=="" or return_date==None:
#             print "Please enter return date"
#             return "Please enter return date"
#         else:
#             print "return date is ok"
    
#     comment=jsondata['comment']
#     print comment

#     ret=traveldao.save_air_ticket_enquiry(jsondata) 
#     return ret

# # this is for genral enquiry 
# def genral_enquiry(jsondata):
#     print jsondata
#     ret=None

#     args=['name','enquiry_type','enquiry_name']
#     print args
    
#     ret=enquiry_validation(jsondata)
#     if ret != "success":
#         return ret
    
#     ret=validation_all_field(args,jsondata)
#     if ret != "success":
#         return ret

#     comment=jsondata['comment'] 
#     print comment


#     ret=traveldao.save_genral_enquiry(jsondata) 
#     return ret

# def rent_car_enquiry(jsondata):
#     print jsondata
#     ret=None
#     args=['name','enquiry_type','enquiry_name','num_of_ppl','car_from','car_to','car_type','hotel_booking']
#     print args
#     ret=enquiry_validation(jsondata)
#     if ret != "success":
#         return ret

#     ret=validation_all_field(args,jsondata)
#     if ret != "success":
#         return ret 

#     date_of_travel=jsondata['date_of_travel']
#     if date_of_travel=="" or date_of_travel==None:
#         print "Please enter date of travel"
#         return "Please enter date of travel"
#     else:
#         print "date of travel is ok"
    
#     return_status=jsondata['return_status']
#     if return_status=="" or return_status==None:
#         print "Please select return status"
#         return "Please select return status"
#     else:
#         print "return status is ok"
    
#     return_date=jsondata['return_date']
#     if return_status==True:
#         if return_date=="" or return_date==None:
#             print "Please enter return_date"
#             return "Please enter return_date"
#         else:   
#             print "return date is ok"
    
#     comment=jsondata['comment'] 
#     print comment

#     ret=traveldao.save_rent_car_enquiry(jsondata) 
#     return ret

# def bus_on_hire_enquiry(jsondata):
#     print jsondata
#     ret=None
#     args=['name','enquiry_type','enquiry_name','num_of_ppl','bus_from','bus_to','bus_type','hotel_booking',]
#     print args
    
#     ret=enquiry_validation(jsondata)
#     if ret != "success":
#         return ret
    
#     ret=validation_all_field(args,jsondata)
#     if ret != "success":
#         return ret
    
#     date_of_travel=jsondata['date_of_travel']
#     if date_of_travel=="" or date_of_travel==None:
#         if (date_of_travel>=date.today()):

#             print "Please enter date of travel" 
#             return "Please enter date of travel"
#         else:
#             print "date of travel is ok"
    
#     comment=jsondata['comment']
#     print comment

#     ret=traveldao.save_busonhire_enquiry(jsondata) 
#     return ret

# def bus_ticket_enquiry(jsondata):
#     print jsondata
#     ret=None

#     args=['name','enquiry_type','enquiry_name','num_of_adults','num_of_kids','bus_from','bus_to','drop_to_source','pickup_from_destination','hotel_booking','car_booking']
#     print args
    
#     ret=enquiry_validation(jsondata)
#     if ret != "success":
#         return ret
    
#     ret=validation_all_field(args,jsondata)
#     if ret != "success":
#         return ret

#     date_of_travel=jsondata['date_of_travel']
#     present_date=int(time.time())
#     valid_date=int(time.mktime(datetime.strptime(str(date_of_travel), "%Y-%m-%d %H:%M:%S").timetd lb )))

#     if date_of_travel=="" or date_of_travel==None:
#         print "Please enter date of travel"
#         return "Please enter date of travel"
#     elif present_date>valid_date:
#             print "please enter valid date"
#             return "please enter valid date"
#     else:
#         print"ok"

#     return_status=jsondata['return_status']
#     if return_status=="" or return_status==None:
#         print "Please select return status"
#         return "Please select return status"
#     else:
#         print "return status is ok"
    
#     if return_status==True:
#         return_date=jsondata['return_date']
#         if return_date=="" or return_date==None:
#             print "Please enter return date"
#             return "Please enter return date"
#         else:
#             print "return date is ok"
    
#     comment=jsondata['comment']
#     print comment
#     ret=traveldao.save_bus_ticket_enquiry(jsondata) 
#     return ret

# def train_ticket_enquiry(jsondata):
#     print jsondata
#     ret=None
    
#     args=['name','enquiry_type','enquiry_name','num_of_adults','num_of_kids','train_from','train_to','drop_to_source','pickup_from_destination','hotel_booking','car_booking']
#     print args
    
#     ret=enquiry_validation(jsondata)
#     if ret != "success":
#         return ret
    
#     ret=validation_all_field(args,jsondata)
#     if ret != "success":
#         return ret
#     date_of_travel=jsondata['date_of_travel']
#     if date_of_travel=="" or date_of_travel==None:
#         print "Please enter date of travel"
#         return "Please enter date of travel"
#     else:
#         print "date of travel is ok"
    
#     return_status=jsondata['return_status']
#     if return_status=="" or return_status==None:
#         print "Please select return status"
#         return "Please select return status"
#     else:
#         print "return status is ok"
    
#     if return_status==True:
#         return_date=jsondata['return_date']
#         if return_date=="" or return_date==None:
#             print "Please enter return date"
#             return "Please enter return date"
#         else:
#             print "return date is ok"

#     comment=jsondata['comment']
#     print comment

#     ret=traveldao.save_train_ticket_enquiry(jsondata) 
#     return ret

  
'''old validation   
    
def enquiry_validation(jsondata):
   
    # mobile no validation

    mobile_no=jsondata['mobile_no']
    if mobile_no=="" or mobile_no==None:
        print "Please enter mobile number"
        return "Please enter mobile number"
 
    if len(mobile_no) != 10 or mobile_no== "" or mobile_no==None:
        print "Please enter valid mobile number"
        return "Please enter valid mobile number"

    email_id=jsondata['email_id']
    if email_id=="" or email_id==None:
        print "Please enter email id"
        return "Please enter email id"


    email_val = re.match('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$', email_id)

    if email_val == None:
        print "Please enter valid email id"
        return"Please enter valid email id"

    return "success"
    
def date_validation(second_date,first_date=None):
    print second_date
    temp=first_date
    if first_date == None:
        first_date=int(time.time())
    else:
        first_date=int(time.mktime(datetime.strptime(str(first_date), "%Y-%m-%d").timetuple()))

    second_date=int(time.mktime(datetime.strptime(str(second_date), "%Y-%m-%d").timetuple()))
    print first_date
    print second_date
    if first_date>second_date:
        print "please enter valid date"
        if temp==None:
            return "travel date must be greater than current date" 
        else:
            return "return date must be greater than travel date" 

    return "success"

def validation_all_field(args,args1,jsondata ,field_details):
    # print args
    for i in args:
        # print i
        if i in jsondata:
            print i
            val=jsondata[i]
            print val
            if val =="" or val==None:
                return i+" field is required"
    for i in range(len(field_details)):
        for j in args1:
            if j in field_details[i]:
                val=field_details[i][j]
                print val
                if val =="" or val==None:
                    return "In travel "+str(i+1)+" "+j+" field is required"

        ret=date_validation(field_details[i]['date_of_travel'])
        if ret != "success":
            return ret
        
        return_status=field_details[i]['return_status']
        if return_status=="" or return_status==None:
            print "Please select return status"
            return "Please select return status"

        if return_status==True or return_status==1:
            return_date=field_details[i]['return_date']
            if return_date=="" or return_date==None:
                print "Please enter return date"
                return "Please enter return date"

            ret=date_validation(return_date,field_details[i]['date_of_travel'])
            if ret != "success":
                return ret
        

    ret=enquiry_validation(jsondata)
    if ret != "success":
        return ret 
    
    return "success"

def train_bus_air_ticket_enquiry(jsondata):
    print jsondata
    ret=None
    if jsondata['enquiry_type']=="air_ticket":
        jsondata["num_of_kids"]=0
    args=['name','enquiry_type','enquiry_name','num_of_adults','num_of_kids','travel_from','travel_to','date_of_travel','drop_to_source','pickup_from_destination','hotel_booking','car_booking']
    print args
    
    ret=validation_all_field(args,jsondata)
    if ret != "success":
        return ret

    return_status=jsondata['return_status']
    if return_status=="" or return_status==None:
        print "Please select return status"
        return "Please select return status"

    if return_status==True or return_status==1:
        return_date=jsondata['return_date']
        if return_date=="" or return_date==None:
            print "Please enter return date"
            return "Please enter return date"

        ret=date_validation(return_date,jsondata['date_of_travel'])
        if ret != "success":
            return ret

    comment_booking=jsondata['comment_booking']
    print comment_booking

    ret=traveldao.save_train_bus_air_ticket_enquiry(jsondata) 
    return ret

def bus_car_enquiry(jsondata):
    print jsondata
    ret=None
    args=['name','enquiry_type','enquiry_name','num_of_ppl','travel_from','travel_to','return_status','travel_type','date_of_travel','hotel_booking']
    print args
    ret=validation_all_field(args,[],jsondata,[])


    ret=date_validation(jsondata['date_of_travel'])
    if ret != "success":
        return ret

        
    if jsondata['enquiry_type']=="rent_car":
        return_status=jsondata['return_status']
        if return_status==True or return_status==1:
            return_date=jsondata['return_date']
            if return_date=="" or return_date==None:
                print "Please enter return date"
                return "Please enter return date"

            ret=date_validation(return_date,jsondata['date_of_travel'])
            if ret != "success":
                return ret
    else:
        jsondata['return_status']=0
        jsondata['return_date']="0000-00-00 00:00:00"
    
    ret=traveldao.save_bus_car_enquiry(jsondata) 
    return ret

    # return "success"

def hotel_reservation_enquiry(jsondata):
    print jsondata
    hotel_details=jsondata['hotel_details']
    ret=None

    args=['name','enquiry_type','enquiry_name']
    args1=['num_of_adults','num_of_kids','checkin_date','checkout_date','destination','car_booking','air_ticket','bus_ticket','train_ticket']
    # print args

    ret=validation_all_field(args,args1,jsondata,hotel_details)
    if ret != "success":
        return ret

    for i  in range(len(hotel_details)):
        ret=date_validation(hotel_details[i]['checkin_date'])
        if ret != "success":
            return ret
        ret=date_validation(hotel_details[i]['checkout_date'],hotel_details[i]['checkin_date'])
        if ret != "success":
            return ret

    ret=traveldao.save_hotelreservation_enquiry(jsondata) 
    return ret
    # return "success"


'''      