from cerberus import Validator
import json


def validation_all_field(jsondata):
	if jsondata['enquiry_type']=='air_ticket' or jsondata['enquiry_type']=='bus_ticket' or jsondata['enquiry_type']=='train_ticket':
		schema=train_bus_air_schema
		# print schema
	elif jsondata['enquiry_type']=='bus_on_hire' or jsondata['enquiry_type']=='rent_car':
		schema=bus_car_schema
	elif jsondata['enquiry_type']=='hotel_reservation':
		schema=hotel_schema
	elif jsondata['enquiry_type']=='general_enquiry':
		schema=general_schema
	else:
		return "Enquiry type not correct"

	v = Validator(schema)
	status = v.validate(jsondata)    
	print status

	errorArr = []
	if not status:
		# print "invalid syntax"
		# print(v.errors)
		
		for i in v.errors.keys():
			if i != "field_details":
				temp={}
				temp["field"]=i
				temp["error"]=i.replace("_"," ")+ " is invalid"
				errorArr.append(temp)
				# return (i+ " is invalid")
			else:
				# print v.errors["travel_details"][0][0]
				
				for field in (v.errors["field_details"]):
					print field
					for j in field:
						print field[j]
						for  k in range(len(field[j])):
							print k
							print field[j][k]
							for l in field[j][k]:
								temp={}
								temp["field"]=l
								temp["error"]=l.replace("_"," ")+ " is invalid"
								errorArr.append(temp)
								# errorArr.append(l+ " is invalid")

		
	if  errorArr==[]:
		return "success"

	else : 
		return errorArr



train_bus_air_schema={
	"name": {
		"type": "string",
		"required": True,"empty":False

	},
	"mobile_no": {
		"type": "string",
		"required": True,"empty":False,
		"minlength":10,"maxlength":10
	},
	"email_id": {
		"type": "string",
		"required": True,"empty":False,
		'regex': '^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$'
	},
	"enquiry_name": {
		"type": "string",
		"required": True,"empty":False
	},
	"enquiry_type": {
		"type": "string",
			"required": True,"empty":False
	},
	"field_details": {
        'type': "list",
        'allow_unknown': True,
        'schema': {"type":"dict",'allow_unknown': True,
		"schema":{"num_of_adults": {
			"type": "integer",
			"required": True,"empty":False
		},
		"num_of_kids": {
			"type": "integer",
			"required": True,"empty":True
		},
		"travel_from": {
			"type": "string",
			"required": True,'empty':False
		},
		"travel_to": {
			"type": "string",
			"required": True,"empty":False
		},
		"date_of_travel": {
			"type": "string",
			"required": True,"empty":False
		},
		"return_status": {
			"type": "boolean",
			"required": True,"empty":False
		},
		"return_date": {
			"type": "string","required":False,
			
		},
		"drop_to_source": {
			"type": "boolean",
			"required": True,"empty":False,
		},
		"pickup_from_destination": {
			"type": "boolean",
			"required": True,"empty":False,
		},
		"hotel_booking": {
			"type": "boolean",
			"required": True,"empty":False,
		},
		"car_booking": {
			"type": "boolean",
			"required": True,"empty":False,
		}}
        }
    }
    
    }

bus_car_schema={"name":{
		"type": "string",
		"required": True,"empty":False
		},
		"mobile_no": {
		"type": "string",
		"required": True,"empty":False,
		"minlength":10,"maxlength":10
		},
		"email_id": {
		"type": "string",
		"required": True,"empty":False,
		'regex': '^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$'
		},
		"enquiry_name": {
		"type": "string",
		"required": True,"empty":False
		},
		"enquiry_type": {
		"type": "string",
			"required": True,"empty":False
		},
		"num_of_ppl": {
			"type": "integer",
			"required": True,"empty":False
		},
		"travel_from": {
			"type": "string",
			"required": True,"empty":False
		},
		"travel_to": {
			"type": "string",
			"required": True,"empty":False
		},
		"date_of_travel": {
			"type": "string",
			"required": True,"empty":False
		},
		"return_status": {
			"type": "boolean",
			"required": True,"empty":False
		},
		"return_date": {
			"type": "string","required":False,
			
		},
		"travel_type": {
			"type": "string","required":True
		},"hotel_booking": {
			"type": "boolean",
			"required": True,"empty":False,
		},
		"comment": {
			"type": "string",
			"required": True,
		}}

hotel_schema={"name": {
		"type": "string",
		"required": True,"empty":False
	},
	"mobile_no": {
		"type": "string",
		"required": True,"empty":False,
		"minlength":10,"maxlength":10
	},
	"email_id": {
		"type": "string",
		"required": True,"empty":False,
		'regex': '^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$'
	},
	"enquiry_name": {
		"type": "string",
		"required": True,"empty":False
	},
	"enquiry_type": {
		"type": "string",
			"required": True,"empty":False
	},
	"field_details": {
        'type': "list",
        'allow_unknown': True,
        'schema': {"type":"dict",'allow_unknown': True,
		"schema":{"num_of_adults": {
			"type": "integer",
			"required": True,"empty":False
		},
		"num_of_kids": {
			"type": "integer",
			"required": True,"empty":False
		},
		"checkin_date": {
			"type": "string",
			"required": True,"empty":False
		},
		"checkout_date": {
			"type": "string",
			"required": True,"empty":False
		},
		"destination": {
		"type": "string",
		"required": True,"empty":False
	},
		"car_booking": {
			"type": "boolean",
			"required": True,"empty":False,
		},
		"air_ticket": {
			"type": "boolean",
			"required": True,"empty":False,
		},
		"bus_ticket": {
			"type": "boolean",
			"required": True,"empty":False,
		},
		"train_ticket": {
			"type": "boolean",
			"required": True,"empty":False,
		},
		"comment": {
			"type": "string",
			"required": True,"empty":False,
		}}
		}
	}
}

general_schema={"name":{
		"type": "string",
		"required": True,"empty":False
		},
		"mobile_no": {
		"type": "string",
		"required": True,"empty":False,
		"minlength":10,"maxlength":10
		},
		"email_id": {
		"type": "string",
		"required": True,"empty":False,
		'regex': '^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$'
		},
		"enquiry_name": {
		"type": "string",
		"required": True,"empty":False
		},
		"enquiry_type": {
		"type": "string",
			"required": True,"empty":False
		},
		"comment": {
			"type": "string",
			"required": True,
		}
		}
		