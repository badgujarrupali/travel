from flask import Flask 
import MySQLdb
from config import MysqlInfo
import sys
from datetime import timedelta
import uuid

if sys.version_info.major < 3:
    reload(sys)
sys.setdefaultencoding('utf8')

app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 300

key=str(uuid.uuid4())
app.secret_key=key
app.jinja_env.cache = {}

from app.model import database_connection
from app.view import travel_view